import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class ForgotPasswordPage extends StatefulWidget { const ForgotPasswordPage({super.key}); @override State<ForgotPasswordPage> createState()=>_ForgotPasswordPageState(); }
class _ForgotPasswordPageState extends State<ForgotPasswordPage>{
 final email=TextEditingController();
 Future<void> reset() async {
  try { await Supabase.instance.client.auth.resetPasswordForEmail(email.text.trim());
   if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Correo de recuperación enviado')));
  } catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
 }
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Recuperar contraseña')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
  TextField(controller:email,decoration:const InputDecoration(labelText:'Correo electrónico')),
  const SizedBox(height:20),FilledButton(onPressed:reset,child:const Text('ENVIAR ENLACE'))
 ])));
}
