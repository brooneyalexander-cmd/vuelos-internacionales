import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override State<RegisterPage> createState() => _RegisterPageState();
}
class _RegisterPageState extends State<RegisterPage> {
  final name=TextEditingController(), email=TextEditingController(), pass=TextEditingController();
  Future<void> register() async {
    try {
      final r=await Supabase.instance.client.auth.signUp(
        email: email.text.trim(), password: pass.text,
        data: {'full_name': name.text.trim()}
      );
      if (r.user != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cuenta creada. Revisa tu correo para confirmar.')));
        Navigator.pop(context);
      }
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Crear cuenta')),
    body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
      TextField(controller:name,decoration:const InputDecoration(labelText:'Nombre completo')),
      TextField(controller:email,decoration:const InputDecoration(labelText:'Correo')),
      TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Contraseña')),
      const SizedBox(height:20),FilledButton(onPressed:register,child:const Text('REGISTRARME'))
    ])));
}
