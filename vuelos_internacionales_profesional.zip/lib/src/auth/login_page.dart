import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../client/client_shell.dart';
import '../admin/admin_shell.dart';
import 'register_page.dart';
import 'forgot_password_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    try {
      final result = await Supabase.instance.client.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
      final uid = result.user!.id;
      final profile = await Supabase.instance.client
          .from('profiles').select('role').eq('id', uid).single();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => profile['role'] == 'admin'
            ? const AdminShell() : const ClientShell(),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const Icon(Icons.flight_takeoff, size: 84, color: Colors.blue),
        const Text('VUELOS INTERNACIONALES',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 30),
        TextField(controller: email,
          decoration: const InputDecoration(labelText: 'Correo', border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: password, obscureText: true,
          decoration: const InputDecoration(labelText: 'Contraseña', border: OutlineInputBorder())),
        Align(alignment: Alignment.centerRight, child: TextButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ForgotPasswordPage())),
          child: const Text('¿Olvidaste tu contraseña?'))),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: loading ? null : login,
          child: Text(loading ? 'INGRESANDO...' : 'INICIAR SESIÓN'))),
        TextButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
          child: const Text('Crear una cuenta')),
      ]),
    ))),
  );
}
