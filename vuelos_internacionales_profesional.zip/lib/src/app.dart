import 'package:flutter/material.dart';
import 'auth/login_page.dart';

class VuelosInternacionalesApp extends StatelessWidget {
  const VuelosInternacionalesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Vuelos Internacionales',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue.shade800),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}
