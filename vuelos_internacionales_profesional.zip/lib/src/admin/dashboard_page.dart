import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class DashboardPage extends StatelessWidget{
 const DashboardPage({super.key});
 @override Widget build(BuildContext c)=>FutureBuilder(future:Future.wait([
  Supabase.instance.client.from('profiles').select('id'),
  Supabase.instance.client.from('flights').select('id'),
  Supabase.instance.client.from('reservations').select('id,total')
 ]),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  final d=s.data as List;
  final reservations=d[2] as List;
  final total=reservations.fold<num>(0,(a,b)=>a+(b['total']??0));
  return GridView.count(crossAxisCount:2,padding:const EdgeInsets.all(16),children:[
   _card(Icons.people,'Usuarios','${(d[0] as List).length}'),
   _card(Icons.flight,'Vuelos','${(d[1] as List).length}'),
   _card(Icons.airplane_ticket,'Reservas','${reservations.length}'),
   _card(Icons.payments,'Ventas','\$ $total'),
  ]);
 }));
 Widget _card(IconData i,String l,String v)=>Card(child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(i,size:38),Text(v,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(l)])));
}
