import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class ManageReservationsPage extends StatelessWidget{const ManageReservationsPage({super.key});
 @override Widget build(BuildContext c)=>FutureBuilder<List<dynamic>>(future:Supabase.instance.client.from('reservations').select().order('created_at',ascending:false),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  return ListView(children:(s.data??[]).map((r)=>ListTile(leading:const Icon(Icons.airplane_ticket),title:Text('Reserva ${r['id'].toString().substring(0,8)}'),subtitle:Text('Estado: ${r['status']}'),trailing:Text('\$ ${r['total']}'))).toList());
 }));
}
