import 'package:flutter/material.dart';
import 'dashboard_page.dart';
import 'manage_flights_page.dart';
import 'manage_reservations_page.dart';

class AdminShell extends StatefulWidget { const AdminShell({super.key}); @override State<AdminShell> createState()=>_AdminShellState(); }
class _AdminShellState extends State<AdminShell>{
 int page=0;
 final titles=['Dashboard','Vuelos','Reservas'];
 @override Widget build(BuildContext c){
  final pages=[const DashboardPage(),const ManageFlightsPage(),const ManageReservationsPage()];
  return Scaffold(appBar:AppBar(title:Text('ADMINISTRACIÓN • ${titles[page]}')),
   drawer:Drawer(child:ListView(children:[
    const DrawerHeader(child:Column(children:[Icon(Icons.admin_panel_settings,size:55),Text('Panel Administrativo',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))])),
    ListTile(leading:const Icon(Icons.dashboard),title:const Text('Dashboard'),onTap:(){setState(()=>page=0);Navigator.pop(c);}),
    ListTile(leading:const Icon(Icons.flight),title:const Text('Gestionar vuelos'),onTap:(){setState(()=>page=1);Navigator.pop(c);}),
    ListTile(leading:const Icon(Icons.confirmation_num),title:const Text('Reservas'),onTap:(){setState(()=>page=2);Navigator.pop(c);}),
   ])),body:pages[page]);
 }
}
