import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class ManageFlightsPage extends StatefulWidget{const ManageFlightsPage({super.key});@override State<ManageFlightsPage> createState()=>_ManageFlightsPageState();}
class _ManageFlightsPageState extends State<ManageFlightsPage>{
 Future<void> add() async{
  final o=TextEditingController(),d=TextEditingController(),a=TextEditingController(),p=TextEditingController();
  await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Nuevo vuelo'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   TextField(controller:o,decoration:const InputDecoration(labelText:'Origen')),
   TextField(controller:d,decoration:const InputDecoration(labelText:'Destino')),
   TextField(controller:a,decoration:const InputDecoration(labelText:'Aerolínea')),
   TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Precio')),
  ]),actions:[FilledButton(onPressed:() async{await Supabase.instance.client.from('flights').insert({'origin':o.text,'destination':d.text,'airline':a.text,'price':num.tryParse(p.text)??0,'active':true,'departure_at':DateTime.now().toIso8601String()});if(c.mounted)Navigator.pop(c);},child:const Text('Guardar'))]));
  setState((){});
 }
 @override Widget build(BuildContext c)=>Scaffold(floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)),body:FutureBuilder<List<dynamic>>(future:Supabase.instance.client.from('flights').select().order('created_at',ascending:false),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  return ListView(children:(s.data??[]).map((f)=>ListTile(title:Text('${f['origin']} → ${f['destination']}'),subtitle:Text('${f['airline']} • \$${f['price']}'),trailing:Switch(value:f['active']==true,onChanged:(v) async{await Supabase.instance.client.from('flights').update({'active':v}).eq('id',f['id']);setState((){});}))).toList());
 }));
}
