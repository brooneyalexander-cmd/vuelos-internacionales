import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class ReservationsPage extends StatelessWidget{
 const ReservationsPage({super.key});
 @override Widget build(BuildContext c){
  final uid=Supabase.instance.client.auth.currentUser?.id;
  return StreamBuilder<List<Map<String,dynamic>>>(stream:Supabase.instance.client.from('reservations').stream(primaryKey:['id']).eq('user_id',uid??''),builder:(c,s){
   final data=s.data??[];
   if(data.isEmpty)return const Center(child:Text('No tienes reservas todavía'));
   return ListView(children:data.map((r)=>ListTile(leading:const Icon(Icons.airplane_ticket),title:Text('Reserva ${r['id'].toString().substring(0,8)}'),subtitle:Text('Estado: ${r['status']} • Total: \$ ${r['total']}'))).toList());
  });
 }
}
