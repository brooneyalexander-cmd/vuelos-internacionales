import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'payment_page.dart';

class FlightsPage extends StatefulWidget { const FlightsPage({super.key}); @override State<FlightsPage> createState()=>_FlightsPageState(); }
class _FlightsPageState extends State<FlightsPage>{
 late Future<List<dynamic>> data;
 @override void initState(){super.initState();data=Supabase.instance.client.from('flights').select().eq('active',true).order('departure_at');}
 @override Widget build(BuildContext c)=>FutureBuilder<List<dynamic>>(future:data,builder:(c,s){
  if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
  if(s.hasError)return Center(child:Text('Error cargando vuelos: ${s.error}'));
  final items=s.data??[];
  if(items.isEmpty)return const Center(child:Text('No hay vuelos disponibles'));
  return ListView.builder(padding:const EdgeInsets.all(16),itemCount:items.length,itemBuilder:(c,i){
   final f=items[i];
   return Card(child:ListTile(
    leading:const Icon(Icons.flight,size:34),
    title:Text('${f['origin']} → ${f['destination']}'),
    subtitle:Text('${f['airline']}\nSalida: ${f['departure_at']}'),
    isThreeLine:true,
    trailing:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      Text('\$ ${f['price']}',style:const TextStyle(fontWeight:FontWeight.bold)),
      TextButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>PaymentPage(flight:f))),child:const Text('Comprar'))
    ]),
   ));
  });
 });
}
