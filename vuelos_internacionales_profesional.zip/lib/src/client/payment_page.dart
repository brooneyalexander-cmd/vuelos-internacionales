import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

class PaymentPage extends StatefulWidget {
 final Map flight; const PaymentPage({super.key,required this.flight});
 @override State<PaymentPage> createState()=>_PaymentPageState();
}
class _PaymentPageState extends State<PaymentPage>{
 bool loading=false;
 Future<void> reserve() async {
  setState(()=>loading=true);
  try {
   final user=Supabase.instance.client.auth.currentUser!;
   final id=const Uuid().v4();
   await Supabase.instance.client.from('reservations').insert({
    'id':id,'user_id':user.id,'flight_id':widget.flight['id'],
    'status':'pending_payment','total':widget.flight['price']
   });
   if(mounted) showDialog(context:context,builder:(_)=>AlertDialog(
    title:const Text('Reserva creada'),
    content:const Text('La reserva quedó creada. Conecta tu backend seguro de Stripe/Wompi/Mercado Pago para confirmar el cobro real mediante webhook.'),
    actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Aceptar'))]));
  } catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  finally{if(mounted)setState(()=>loading=false);}
 }
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Confirmar compra')),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Text('${widget.flight['origin']} → ${widget.flight['destination']}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
  const SizedBox(height:12),Text('Aerolínea: ${widget.flight['airline']}'),
  Text('Total: \$ ${widget.flight['price']}'),
  const Spacer(),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:loading?null:reserve,icon:const Icon(Icons.payment),label:Text(loading?'PROCESANDO...':'CONTINUAR AL PAGO')))
 ])));
}
