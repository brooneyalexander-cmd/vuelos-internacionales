import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class ProfilePage extends StatelessWidget{
 const ProfilePage({super.key});
 @override Widget build(BuildContext c)=>ListView(children:[
  const UserAccountsDrawerHeader(accountName:Text('Mi cuenta'),accountEmail:Text('Vuelos Internacionales'),currentAccountPicture:CircleAvatar(child:Icon(Icons.person,size:40))),
  const ListTile(leading:Icon(Icons.person),title:Text('Editar perfil')),
  const ListTile(leading:Icon(Icons.notifications),title:Text('Notificaciones')),
  ListTile(leading:const Icon(Icons.logout),title:const Text('Cerrar sesión'),onTap:() async{await Supabase.instance.client.auth.signOut();if(c.mounted)Navigator.of(c).popUntil((r)=>r.isFirst);})
 ]);
}
