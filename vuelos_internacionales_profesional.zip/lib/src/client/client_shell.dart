import 'package:flutter/material.dart';
import 'home_page.dart';
import 'flights_page.dart';
import 'reservations_page.dart';
import 'profile_page.dart';

class ClientShell extends StatefulWidget { const ClientShell({super.key}); @override State<ClientShell> createState()=>_ClientShellState(); }
class _ClientShellState extends State<ClientShell>{
 int index=0;
 @override Widget build(BuildContext c){
  final pages=[const HomePage(),const FlightsPage(),const ReservationsPage(),const ProfilePage()];
  return Scaffold(
   appBar:AppBar(title:const Text('✈️ Vuelos Internacionales')),
   body:pages[index],
   bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const[
    NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Inicio'),
    NavigationDestination(icon:Icon(Icons.search),label:'Vuelos'),
    NavigationDestination(icon:Icon(Icons.airplane_ticket),label:'Reservas'),
    NavigationDestination(icon:Icon(Icons.person_outline),label:'Perfil'),
   ]),
  );
 }
}
