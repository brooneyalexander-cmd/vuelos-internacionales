import 'package:flutter/material.dart';
import 'flights_page.dart';
class HomePage extends StatelessWidget{
 const HomePage({super.key});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Tu próximo destino comienza aquí',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
  const SizedBox(height:18),
  Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
   const TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.flight_takeoff),labelText:'Origen')),
   const TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.flight_land),labelText:'Destino')),
   const SizedBox(height:12),
   SizedBox(width:double.infinity,child:FilledButton.icon(
    icon:const Icon(Icons.search),label:const Text('BUSCAR VUELOS'),
    onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const FlightsPage()))))
  ]))),
  const SizedBox(height:24),const Text('Reserva vuelos internacionales de forma rápida y segura.',
   style:TextStyle(fontSize:17)),
 ]);
}
