# Backend de pagos
Nunca coloques claves secretas de Stripe, Wompi o Mercado Pago dentro de Flutter.

Implementa un backend (Node.js, Supabase Edge Function o servidor propio) que:
1. Reciba el ID de la reserva.
2. Cree la intención/preferencia de pago.
3. Devuelva al móvil únicamente datos públicos.
4. Reciba webhooks del proveedor.
5. Cambie reservations.status a paid / failed.
6. Genere el comprobante y notificación.

Esto evita manipulación de precios desde el teléfono.
