-- VUELOS INTERNACIONALES - SUPABASE / POSTGRESQL
create extension if not exists "uuid-ossp";

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 email text,
 role text not null default 'client' check (role in ('client','admin')),
 created_at timestamptz default now()
);

create table public.flights (
 id uuid primary key default uuid_generate_v4(),
 airline text not null,
 origin text not null,
 destination text not null,
 departure_at timestamptz not null default now(),
 arrival_at timestamptz,
 price numeric not null,
 currency text default 'COP',
 available_seats integer default 100,
 active boolean default true,
 created_at timestamptz default now()
);

create table public.reservations (
 id uuid primary key,
 user_id uuid not null references auth.users(id) on delete cascade,
 flight_id uuid not null references public.flights(id) on delete restrict,
 status text not null default 'pending_payment',
 total numeric not null,
 payment_reference text,
 created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.flights enable row level security;
alter table public.reservations enable row level security;

create policy "users read own profile" on public.profiles for select using (auth.uid()=id);
create policy "users read active flights" on public.flights for select using (active=true);
create policy "users own reservations" on public.reservations for select using (auth.uid()=user_id);
create policy "users create reservations" on public.reservations for insert with check (auth.uid()=user_id);

-- Admin policies use role stored in profile
create policy "admins manage flights" on public.flights for all using (
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);
create policy "admins manage reservations" on public.reservations for all using (
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);
