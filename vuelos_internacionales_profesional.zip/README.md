# ✈️ Vuelos Internacionales - Versión Profesional

Aplicación Flutter para Android y iPhone con:

## Cliente
- Registro e inicio de sesión
- Recuperación de contraseña
- Perfiles de usuario
- Vuelos desde base de datos
- Compra y reservas
- Historial de reservas
- Preparada para pagos reales
- Preparada para notificaciones

## Administrador integrado
- Dashboard de estadísticas
- Crear vuelos
- Activar/desactivar vuelos
- Ver reservas
- Control de usuarios mediante Supabase

## Conexión real necesaria
Este proyecto ya contiene la arquitectura de conexión. Para activarla:

1. Crear proyecto en Supabase.
2. Ejecutar database/schema.sql en SQL Editor.
3. Copiar .env.example a .env y colocar credenciales.
4. Crear un usuario y cambiar su role a admin si será administrador.
5. Configurar backend seguro para pagos.
6. Ejecutar flutter pub get.
7. Ejecutar flutter run.

### Importante
Las APIs de vuelos reales y las pasarelas de pago requieren cuentas, contratos o claves propias del proveedor. Las claves privadas nunca deben estar dentro de la app móvil.
